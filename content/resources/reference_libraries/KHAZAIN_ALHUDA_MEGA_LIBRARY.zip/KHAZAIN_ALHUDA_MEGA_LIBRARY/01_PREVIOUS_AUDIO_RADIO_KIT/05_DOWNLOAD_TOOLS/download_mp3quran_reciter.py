#!/usr/bin/env python3
"""Download MP3Quran surah files ONLY after rights holder permission is obtained.
This script intentionally requires --confirm-written-permission and uses only API-listed server paths.
"""
import argparse,json,urllib.request,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
META=ROOT/'01_QURAN_RECITERS'/'metadata'
OUT=ROOT/'01_QURAN_RECITERS'/'audio_authorized_only'
def main():
 p=argparse.ArgumentParser(); p.add_argument('--reciter-id',type=int,required=True); p.add_argument('--mushaf-id',type=int,required=True); p.add_argument('--confirm-written-permission',action='store_true'); p.add_argument('--max-files',type=int,default=114); p.add_argument('--delay',type=float,default=0.6); a=p.parse_args()
 if not a.confirm_written_permission: raise SystemExit('STOP: obtain written permission for redistribution, then add --confirm-written-permission.')
 src=META/'mp3quran_reciters.json'
 if not src.exists(): raise SystemExit('Run sync_mp3quran_metadata.py first.')
 data=json.loads(src.read_text(encoding='utf-8'))
 reciters=data.get('reciters',[])
 rec=next((x for x in reciters if int(x.get('id',-1))==a.reciter_id),None)
 if not rec: raise SystemExit('Reciter ID not found in API catalog.')
 msh=next((x for x in rec.get('moshaf',[]) if int(x.get('id',-1))==a.mushaf_id),None)
 if not msh: raise SystemExit('Mushaf ID not found for this reciter.')
 server=msh.get('server','').rstrip('/')+'/'
 if not server.startswith('https://'): raise SystemExit('Refusing non-HTTPS or missing server URL.')
 surahs=[int(x) for x in str(msh.get('surah_list','')).split(',') if x.isdigit()]
 if not surahs: surahs=list(range(1,int(msh.get('surah_total',114))+1))
 surahs=surahs[:max(1,min(a.max_files,114))]
 folder=OUT/f'reciter_{a.reciter_id}_mushaf_{a.mushaf_id}'; folder.mkdir(parents=True,exist_ok=True)
 report=[]
 for n in surahs:
  url=server+f'{n:03d}.mp3'; dest=folder/f'{n:03d}.mp3'
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'KhazainAlHuda/1.0'})
   with urllib.request.urlopen(req,timeout=90) as r:
    if 'audio' not in r.headers.get('Content-Type','').lower() and 'octet-stream' not in r.headers.get('Content-Type','').lower():
     # allow server MP3s with application/octet-stream; reject HTML pages
     pass
    body=r.read()
   if len(body)<1024 or body[:3] not in (b'ID3',b'\xff\xfb',b'\xff\xf3',b'\xff\xf2'):
    raise ValueError('Response did not look like a valid MP3 file')
   dest.write_bytes(body); sha=hashlib.sha256(body).hexdigest()
   report.append({'surah':n,'url':url,'file':str(dest.relative_to(ROOT)),'bytes':len(body),'sha256':sha,'status':'downloaded_verified'})
  except Exception as e: report.append({'surah':n,'url':url,'status':'failed','error':str(e)})
  time.sleep(a.delay)
 out=ROOT/'07_REPORTS'/f'download_reciter_{a.reciter_id}_mushaf_{a.mushaf_id}.json'; out.write_text(json.dumps({'permission_confirmation':True,'items':report},ensure_ascii=False,indent=2),encoding='utf-8')
 print(f"Completed: {sum(x['status']=='downloaded_verified' for x in report)} / {len(report)}. Report: {out}")
if __name__=='__main__': main()
