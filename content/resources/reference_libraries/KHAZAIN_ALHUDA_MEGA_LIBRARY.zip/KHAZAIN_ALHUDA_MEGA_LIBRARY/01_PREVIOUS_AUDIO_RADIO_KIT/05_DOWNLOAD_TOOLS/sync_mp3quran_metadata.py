#!/usr/bin/env python3
"""Fetch publicly documented MP3Quran metadata only; does not download recordings."""
import argparse, json, urllib.request, urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'01_QURAN_RECITERS'/'metadata'
ENDPOINTS={
 'reciters':'https://www.mp3quran.net/api/v3/reciters?language=ar',
 'radios':'https://www.mp3quran.net/api/v3/radios?language=ar',
 'surahs':'https://www.mp3quran.net/api/v3/suwar?language=ar',
 'mushafs':'https://www.mp3quran.net/api/v3/moshaf?language=ar',
 'riwayat':'https://www.mp3quran.net/api/v3/riwayat?language=ar',
 'tafsir':'https://www.mp3quran.net/api/v3/tafasir?language=ar',
}
def main():
 p=argparse.ArgumentParser(); p.add_argument('--timeout',type=int,default=30); a=p.parse_args()
 OUT.mkdir(parents=True,exist_ok=True); report=[]
 for name,url in ENDPOINTS.items():
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'KhazainAlHuda/1.0','Accept':'application/json'})
   with urllib.request.urlopen(req,timeout=a.timeout) as r: raw=r.read(); final=r.geturl()
   obj=json.loads(raw.decode('utf-8-sig'))
   dest=OUT/f'mp3quran_{name}.json'; dest.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
   report.append({'name':name,'status':'downloaded','url':url,'final_url':final,'file':str(dest.relative_to(ROOT)),'bytes':len(raw)})
  except Exception as e: report.append({'name':name,'status':'failed','url':url,'error':str(e)})
 (ROOT/'07_REPORTS'/'mp3quran_metadata_sync_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
