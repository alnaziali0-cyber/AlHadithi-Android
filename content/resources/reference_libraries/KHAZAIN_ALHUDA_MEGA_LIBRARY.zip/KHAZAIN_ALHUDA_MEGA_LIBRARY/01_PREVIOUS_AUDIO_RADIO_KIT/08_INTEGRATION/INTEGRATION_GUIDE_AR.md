# دمج الصوتيات والإذاعات في تطبيق خزائن الهدى

## وضع الإذاعات
اقرأ `04_SHIA_RADIO/official_players/radio_stations.json`. استخدم `player_url` داخل WebView أو افتح الصفحة الرسمية داخل مشغل ويب عند عدم توفر direct_stream_url. لا تنشئ رابط HLS أو MP3 بالتخمين.

## وضع قراء القرآن
شغّل `05_DOWNLOAD_TOOLS/sync_mp3quran_metadata.py` في بيئة فيها إنترنت لجلب أسماء القراء والمصاحف والسور والإذاعات والتفاسير من API الرسمي إلى JSON. يمكن استخدام روابط الصوت المقدمة من API للتشغيل المتصل وفق شروط المصدر.

## تنزيل مصحف قارئ كاملاً
لا تستخدم `download_mp3quran_reciter.py` إلا بعد الحصول على إذن كتابي واضح لإعادة التوزيع؛ ثم شغّل مزامنة البيانات أولاً، وبعدها: `python download_mp3quran_reciter.py --reciter-id ID --mushaf-id ID --confirm-written-permission`. ابدأ بقارئ واحد واختبر الحجم والروابط.

## واجهة عنصر الصوت المقترحة
```json
{
  "id": "audio-unique-id",
  "title": "اسم التسجيل",
  "category": "quran|adhan|dua|ziyarat|majlis|latmiya|lecture|radio",
  "performer": "اسم القارئ أو الرادود",
  "source_name": "اسم الجهة",
  "source_url": "https://...",
  "playback_url": "https://...",
  "offline_file": null,
  "rights_status": "stream_only|permission_pending|licensed_offline",
  "license_url": null,
  "attribution": "النسبة المطلوبة",
  "duration_seconds": null
}
```

لا تسمح بزر «تنزيل» إلا عندما تكون `rights_status` مساوية لـ `licensed_offline` وتوجد بيانات الترخيص.
