PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS rights_grants (
  id TEXT PRIMARY KEY,
  rights_holder TEXT NOT NULL,
  license_name TEXT,
  permission_document_uri TEXT,
  commercial_use INTEGER NOT NULL DEFAULT 0,
  offline_use INTEGER NOT NULL DEFAULT 0,
  redistribution INTEGER NOT NULL DEFAULT 0,
  stream_embed INTEGER NOT NULL DEFAULT 0,
  territories TEXT,
  attribution TEXT,
  expiry_date TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING'
);
CREATE TABLE IF NOT EXISTS audio_assets (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  performer TEXT,
  producer TEXT,
  source_url TEXT,
  stream_url TEXT,
  download_url TEXT,
  local_path TEXT,
  mime_type TEXT,
  duration_ms INTEGER,
  size_bytes INTEGER,
  sha256 TEXT,
  rights_grant_id TEXT,
  status TEXT NOT NULL DEFAULT 'NEEDS_PERMISSION',
  updated_at TEXT,
  FOREIGN KEY(rights_grant_id) REFERENCES rights_grants(id)
);
CREATE TABLE IF NOT EXISTS radio_stations (
  id TEXT PRIMARY KEY,
  name_ar TEXT NOT NULL,
  official_url TEXT NOT NULL,
  player_url TEXT,
  direct_stream_url TEXT,
  frequency_note TEXT,
  rights_status TEXT NOT NULL DEFAULT 'OFFICIAL_PLAYER_ONLY'
);
CREATE TABLE IF NOT EXISTS quran_reciters (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  metadata_json TEXT
);
CREATE TABLE IF NOT EXISTS quran_moshafs (
  id INTEGER PRIMARY KEY,
  reciter_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  riwayah TEXT,
  server_url TEXT,
  surah_list TEXT,
  FOREIGN KEY(reciter_id) REFERENCES quran_reciters(id)
);
