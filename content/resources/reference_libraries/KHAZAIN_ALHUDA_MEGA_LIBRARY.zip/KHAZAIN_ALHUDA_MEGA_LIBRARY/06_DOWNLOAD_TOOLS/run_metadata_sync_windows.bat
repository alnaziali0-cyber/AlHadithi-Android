@echo off
cd /d "%~dp0.."
python 06_DOWNLOAD_TOOLS\sync_mp3quran_catalog.py --languages ar,en,fa
python 06_DOWNLOAD_TOOLS\fetch_opendua_dataset.py
pause
