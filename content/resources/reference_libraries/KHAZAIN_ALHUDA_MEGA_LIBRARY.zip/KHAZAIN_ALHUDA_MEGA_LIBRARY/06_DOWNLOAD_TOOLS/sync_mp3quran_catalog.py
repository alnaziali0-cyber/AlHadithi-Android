#!/usr/bin/env python3
"""Fetch MP3Quran public catalogue JSON. Does NOT download audio files."""
from pathlib import Path
import argparse, json, time, urllib.request, urllib.error
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'03_QURAN_AUDIO_CATALOG'/'live_metadata'
BASE='https://www.mp3quran.net/api/v3'
RESOURCES=['languages','reciters','radios','suwar','moshaf','riwayat','tafasir']

def get_json(url, timeout=40):
    req=urllib.request.Request(url,headers={'User-Agent':'KhazainAlHudaResourceSync/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        raw=r.read(); ctype=r.headers.get('Content-Type','')
    obj=json.loads(raw.decode('utf-8-sig'))
    if not isinstance(obj,(dict,list)): raise ValueError('Unexpected JSON root')
    return obj,len(raw),ctype

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--languages',default='ar',help='Comma-separated language tags, e.g. ar,en,fa')
    p.add_argument('--delay',type=float,default=0.5)
    a=p.parse_args(); OUT.mkdir(parents=True,exist_ok=True)
    report=[]
    for lang in [x.strip() for x in a.languages.split(',') if x.strip()]:
        for resource in RESOURCES:
            url=f'{BASE}/{resource}?language={lang}'
            try:
                obj,n,ctype=get_json(url)
                dest=OUT/f'{lang}_{resource}.json'
                dest.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
                report.append({'lang':lang,'resource':resource,'status':'FETCHED_METADATA','bytes':n,'content_type':ctype,'url':url,'file':str(dest.relative_to(ROOT))})
            except Exception as e:
                report.append({'lang':lang,'resource':resource,'status':'FAILED','url':url,'error':f'{type(e).__name__}: {e}'})
            time.sleep(max(0,a.delay))
    rep=ROOT/'10_REPORTS'/'mp3quran_catalog_sync_report.json'
    rep.parent.mkdir(parents=True,exist_ok=True); rep.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"Metadata resources fetched: {sum(x['status']=='FETCHED_METADATA' for x in report)} / {len(report)}")
    print(f"Report: {rep}")
    return 0 if any(x['status']=='FETCHED_METADATA' for x in report) else 2
if __name__=='__main__': raise SystemExit(main())
