#!/usr/bin/env python3
"""Rights-gated downloader for one MP3Quran mushaf. Use only with written redistribution permission."""
from pathlib import Path
import argparse, json, urllib.request, hashlib, re, time
ROOT=Path(__file__).resolve().parents[1]
CAT=ROOT/'03_QURAN_AUDIO_CATALOG'/'live_metadata'
OUT=ROOT/'08_AUTHORIZED_AUDIO'/'quran'

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--language',default='ar')
    p.add_argument('--reciter-id',type=int,required=True)
    p.add_argument('--moshaf-id',type=int,required=True)
    p.add_argument('--permission-proof',required=True,help='Path to permission letter/email saved as PDF/EML/TXT, or a written license URL in your rights register')
    p.add_argument('--max-files',type=int,default=114)
    p.add_argument('--delay',type=float,default=1.0)
    a=p.parse_args()
    proof=Path(a.permission_proof)
    if not proof.exists() and not a.permission_proof.startswith('https://'):
        raise SystemExit('STOP: permission proof path not found. Provide a saved written permission file or HTTPS license URL.')
    catalog=CAT/f'{a.language}_reciters.json'
    if not catalog.exists(): raise SystemExit('Run sync_mp3quran_catalog.py first to fetch the reciter catalogue.')
    data=json.loads(catalog.read_text(encoding='utf-8'))
    rec=next((x for x in data.get('reciters',[]) if int(x.get('id',-1))==a.reciter_id),None)
    if not rec: raise SystemExit('Reciter ID not found in catalogue.')
    mos=next((x for x in rec.get('moshaf',[]) if int(x.get('id',-1))==a.moshaf_id),None)
    if not mos: raise SystemExit('Moshaf ID not found for this reciter.')
    server=mos.get('server','').rstrip('/')+'/'
    if not server.startswith('https://'): raise SystemExit('Non-HTTPS audio server refused.')
    nums=[int(s) for s in str(mos.get('surah_list','')).split(',') if s.isdigit()]
    if not nums: nums=list(range(1,int(mos.get('surah_total',114))+1))
    nums=nums[:max(1,min(114,a.max_files))]
    folder=OUT/f'reciter_{a.reciter_id}_moshaf_{a.moshaf_id}'; folder.mkdir(parents=True,exist_ok=True)
    results=[]
    for n in nums:
        url=server+f'{n:03}.mp3'; dest=folder/f'{n:03}.mp3'
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'KhazainAlHudaAuthorizedAudio/1.0'})
            with urllib.request.urlopen(req,timeout=120) as r: body=r.read(); ctype=r.headers.get('Content-Type','')
            if len(body)<1024 or not (body.startswith(b'ID3') or (len(body)>2 and body[0]==0xFF and (body[1]&0xE0)==0xE0)):
                raise ValueError('File signature is not a valid MP3 header')
            dest.write_bytes(body)
            results.append({'surah':n,'url':url,'file':str(dest.relative_to(ROOT)),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'content_type':ctype,'status':'DOWNLOADED_VERIFIED','permission_proof':a.permission_proof})
        except Exception as e: results.append({'surah':n,'url':url,'status':'DOWNLOAD_FAILED','error':f'{type(e).__name__}: {e}'})
        time.sleep(max(0,a.delay))
    pth=ROOT/'10_REPORTS'/f'authorized_quran_reciter_{a.reciter_id}_moshaf_{a.moshaf_id}.json'
    pth.parent.mkdir(parents=True,exist_ok=True); pth.write_text(json.dumps({'permission_confirmed_by_operator':True,'permission_proof':a.permission_proof,'items':results},ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"Downloaded and verified: {sum(x['status']=='DOWNLOADED_VERIFIED' for x in results)} / {len(results)}")
    print('Report:',pth)
if __name__=='__main__': main()
