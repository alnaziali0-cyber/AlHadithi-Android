#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 06_DOWNLOAD_TOOLS/sync_mp3quran_catalog.py --languages ar,en,fa
python3 06_DOWNLOAD_TOOLS/fetch_opendua_dataset.py
