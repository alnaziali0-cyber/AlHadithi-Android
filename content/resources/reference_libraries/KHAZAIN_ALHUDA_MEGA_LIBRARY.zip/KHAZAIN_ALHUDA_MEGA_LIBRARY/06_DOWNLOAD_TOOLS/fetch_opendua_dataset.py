#!/usr/bin/env python3
"""Fetch OpenDua's published JSON catalogue. Audio recordings are NOT downloaded."""
from pathlib import Path
import json, urllib.request, hashlib
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
URL='https://opendua.org/v0.0.4/catalogue.json'
OUT=ROOT/'07_OPEN_DUA_DATA'/'catalogue.json'

def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    req=urllib.request.Request(URL,headers={'User-Agent':'KhazainAlHudaOpenDuaSync/1.0','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=60) as r:
        raw=r.read(); ctype=r.headers.get('Content-Type',''); final=r.geturl()
    obj=json.loads(raw.decode('utf-8-sig'))
    OUT.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'status':'FETCHED_TEXT_METADATA','url':URL,'final_url':final,'content_type':ctype,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'fetched_at_utc':datetime.now(timezone.utc).isoformat(),'license':'CC BY 4.0 for OpenDua-authored English, transliteration, editorial metadata and dataset structure; underlying religious texts are not claimed by OpenDua; audio recording is under a separate agreement and is excluded.'}
    p=ROOT/'10_REPORTS'/'opendua_sync_report.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Saved OpenDua catalogue text/metadata:',OUT)
    print('No MP3 recordings were downloaded.')
if __name__=='__main__': main()
