# بيانات OpenDua

يمكن تنزيل كتالوج البيانات النصية من خلال:

```bash
python 06_DOWNLOAD_TOOLS/fetch_opendua_dataset.py
```

بحسب توثيق OpenDua، فإن النصوص التحريرية الإنجليزية واللفظ اللاتيني والبيانات الوصفية وبنية مجموعة البيانات مرخصة CC BY 4.0. لا تدّعي OpenDua ملكية النصوص الدينية الأصلية. **التسجيلات الصوتية مسجلة باتفاق منفصل وليست مشمولة بترخيص مجموعة البيانات**؛ لذلك لا يحمّلها هذا السكربت.

نص الإسناد المطلوب بحسب صفحة المطورين:

> OpenDua dataset v0.0.4 (https://opendua.org), by Ihsan Labs at the Human Development Fund. Based on Hisn al-Muslim by Sa'id ibn Ali ibn Wahf al-Qahtani. OpenDua editorial text and dataset structure are licensed CC BY 4.0. Recitation by Muhammad Jumah for OpenDua. OpenDua makes no ownership claim over the underlying religious texts.

تحقق من إصدار الترخيص والمصدر عند كل تحديث.
